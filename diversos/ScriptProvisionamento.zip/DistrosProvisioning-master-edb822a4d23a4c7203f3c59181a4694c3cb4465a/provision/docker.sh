#!/usr/bin/env bash

sudo curl -fsSL https://get.docker.com/ | sh
