#!/usr/bin/env bash

echo ".............................. *************************** .............................."
echo "INSTALLIG VIRTUALBOX"
echo ".............................. *************************** .............................."

sudo add-apt-repository -y 'deb http://download.virtualbox.org/virtualbox/debian yakkety contrib'
sudo wget -q https://www.virtualbox.org/download/oracle_vbox_2016.asc -O- | sudo apt-key add -
sudo wget -q https://www.virtualbox.org/download/oracle_vbox.asc -O- | sudo apt-key add -
sudo apt-get -y -qq update

sudo apt-get -y -qq install virtualbox-5.1
