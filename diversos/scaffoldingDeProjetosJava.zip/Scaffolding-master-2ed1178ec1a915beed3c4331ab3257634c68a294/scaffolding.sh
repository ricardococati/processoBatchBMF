#!/bin/bash
printf "\n\n"
	echo "************************************* Scaffolding v1 ***************************************"

if [ $# -eq 0 ]; 
then
	echo 'Arg1 - Original Name '
	echo 'Arg2 - New Name'
	echo 'Arg3 - Git Repository Resource'
else
	printf "\n"
	echo "******************************** Initializing scaffolding **********************************"
	echo 'Original: ' $1
	echo 'New: ' $2
	echo 'Repository: '$3

	printf "\n"
	echo "******************************* Generating scaffolding dir *********************************"
	rm -rf scaffolding/
    mkdir scaffolding
    cd scaffolding


	printf "\n"
	echo "************************************ Cloning Repository ************************************"
	git clone $3
	
	printf "\n"
	echo "***************************** Replacing the contents of files ******************************"
	find . -type f | xargs sed -i  's/'$1'/'$2'/g'

	printf "\n"
	echo "*********************************** Renaming directories ***********************************"
	for i in $(find . -depth -type d -iname "*"$1"*" | sort -r )
	do
		find . -depth -type d -iname '*'$1'*' | sort -r | xargs rename 's@'$1'@'$2'@gi' {} + 2>/dev/null
	done

	printf "\n"
	echo "******************************** Listing directory content *********************************"
	ls -l

	printf "\n"
	echo "****************************** END ******************************"
fi